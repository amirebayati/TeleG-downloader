#!/usr/bin/env python3
# Usage: py getpic.py <channel_id_or_url>

import os
import sys
import re
import subprocess
from urllib.parse import urlparse
from datetime import datetime
import requests

# ---------- config ----------
CURL_EXE = "./curl.exe"
GOOGLE_RESOLVE_IP = "216.239.38.120"
GOOGLE_HOST_HEADER = "t-me.translate.goog"
# ----------------------------

def now_foldername(channel):
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    safe = re.sub(r"[^\w\-]", "_", channel)
    return f"{ts}_{safe}"

def run_curl(args, timeout=60):
    try:
        proc = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return proc.returncode, proc.stdout, proc.stderr
    except Exception as e:
        return 999, "", str(e)

def curl_download_translate(channel, outpath):
    url = f"https://www.google.com/s/{channel}?_x_tr_sl=el&_x_tr_tl=en&_x_tr_hl=en&_x_tr_pto=wapp"
    args = [
        CURL_EXE,
        "--resolve", f"www.google.com:443:{GOOGLE_RESOLVE_IP}",
        "--header", f"Host: {GOOGLE_HOST_HEADER}",
        "-k",
        "-L",
        url,
        "-o", outpath
    ]
    return run_curl(args)

def curl_download_direct_tme(channel, outpath):
    url = f"https://t.me/s/{channel}"
    args = [CURL_EXE, "-L", url, "-o", outpath]
    return run_curl(args)

def safe_read(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except:
        return ""

def main():
    if len(sys.argv) < 2:
        print("Usage: py getpic.py <channel_id_or_url>")
        sys.exit(1)

    raw = sys.argv[1].strip()
    if raw.startswith("http"):
        parsed = urlparse(raw)
        parts = parsed.path.strip("/").split("/")
        channel = parts[-1] if parts else raw
    else:
        channel = raw

    folder = now_foldername(channel)
    os.makedirs(folder, exist_ok=True)
    index_path = os.path.join(folder, "index.htm")

    if os.path.exists(CURL_EXE):
        print("Trying google-translate curl trick...")
        rc, out, err = curl_download_translate(channel, index_path)
        html = safe_read(index_path)

        if rc != 0 or "<main" not in html:
            print("Translate failed, trying direct t.me...")
            rc2, o2, e2 = curl_download_direct_tme(channel, index_path)
            html = safe_read(index_path)
            if rc2 != 0 or "<main" not in html:
                print("[ERROR] download failed.")
                sys.exit(2)
    else:
        print("curl.exe not found. Using requests...")
        try:
            r = requests.get(f"https://t.me/s/{channel}", headers={"User-Agent":"Mozilla/5.0"}, timeout=20)
            with open(index_path, "w", encoding="utf-8") as f:
                f.write(r.text)
        except Exception as e:
            print("Requests failed:", e)
            sys.exit(2)

    html = safe_read(index_path)
    if "<main" not in html:
        print("[ERROR] page does not contain <main>")
        sys.exit(2)

    print("Downloaded page ok.")

    temp_path = os.path.join(folder, "temp.htm")

    if os.path.exists("style.css"):
        with open("style.css", "r", encoding="utf-8", errors="ignore") as sf, \
             open(temp_path, "w", encoding="utf-8") as tf:
            tf.write(sf.read())
    else:
        with open(temp_path, "w", encoding="utf-8") as tf:
            tf.write("")

    in_block = False
    with open(index_path, "r", encoding="utf-8", errors="ignore") as inf, \
         open(temp_path, "a", encoding="utf-8") as outf:
        for rawline in inf:
            line = rawline.rstrip("\n")
            if in_block:
                outf.write(line + "\n")
            if line == "  </header>":
                in_block = True
            if line == "  </main>":
                in_block = False

    os.replace(temp_path, index_path)

    print("=== Done ===")
    print("Folder:", folder)
    print("Images: disabled (HTML only)")

if __name__ == "__main__":
    main()
